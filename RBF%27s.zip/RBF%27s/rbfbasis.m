function [h] = rbfbasis( r )
%RBFBASIS Summary of this function goes here
%   Detailed explanation goes here
 h = sqrt(r*r+1);

end

